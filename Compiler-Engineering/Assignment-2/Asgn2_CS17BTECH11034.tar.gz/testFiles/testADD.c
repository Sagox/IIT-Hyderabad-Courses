#include <stdio.h>
int main() {
	int b = 0;
	for(int i=4;i<=198;i+=7) {
		b+=i;
	}
	printf("%d\n", b);
	for(int i=-78;i<874;i+=12) {
		b+=i;
	}
	printf("%d\n", b);
	for(int i=3;i>=-78;i-=7) {
		b+=i;
	}
	printf("%d\n", b);
	for(int i=-7854;i<785;i+=798) {
		b+=i;
	}

}
