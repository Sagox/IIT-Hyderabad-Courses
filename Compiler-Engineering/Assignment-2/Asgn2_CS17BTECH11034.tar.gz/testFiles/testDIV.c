#include <stdio.h>
int main() {
	int b = 0;
	for(int i=454646;i>=198;i/=2) {
		b+=i;
	}
	printf("%d\n", b);
	for(int i=-844635;i<=-784;i+=12) {
		b+=i;
	}
	printf("%d\n", b);
}
