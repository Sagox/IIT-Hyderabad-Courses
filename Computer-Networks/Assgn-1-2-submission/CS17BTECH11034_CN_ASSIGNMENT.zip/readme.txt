To make the object file fo into any of the folders:
1) Assignment_1_Q1

To build  feature 1 do: make f1
server format: ./server <port>
client format: ./client <address> <port>

To build feature 2 do: make f2
server format: ./server <port>
client format ./client <address> <port> <fileName>

2) Assignment_1_Q2

To build: make
server format: ./server <port> <maxClients>
client format: ./client <address> <port>

3) Assignment_2

To build: make
server format: ./server <port>
client format: ./client <domainName> <port>

