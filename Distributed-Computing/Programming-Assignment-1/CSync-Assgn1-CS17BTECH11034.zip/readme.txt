List of files

This folder consists of the following files:

1)CS-CS17BTECH11034.cpp
2)report.pdf
3)readme.txt
_____________________________________________________________

Compiling the files

1)To compile the file CS-CS17BTECH11034.cpp use:

g++ CS-CS17BTECH11034.cpp -lpthread -o CS-CS17BTECH11034.o
______________________________________________________________

Executing the program

Before executing there must be a file called inp-params.txt
present in the same directory as the files.

1)To execute the program rw-CS17BTECH11034.cpp use:

./CS-CS17BTECH11034.o
_______________________________________________________________

Output

Each of the programs produce one output files on execution i.e. out-log.txt
