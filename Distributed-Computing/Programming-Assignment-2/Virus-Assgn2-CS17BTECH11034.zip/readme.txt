List of files

This folder consists of the following files:

1)Virus1-CS17BTECH11034.cpp
2)Virus2-CS17BTECH11034.cpp
3)report.pdf
4)readme.txt
_____________________________________________________________

Compiling the files

1)To compile the file Virus1-CS17BTECH11034.cpp use:

g++ Virus1-CS17BTECH11034.cpp -lpthread -o Virus1-CS17BTECH11034.o

2)To compile the file Virus2-CS17BTECH11034.cpp use:

g++ Virus2-CS17BTECH11034.cpp -lpthread -o Virus2-CS17BTECH11034.o
______________________________________________________________

Executing the program

Before executing there must be a file called inp-params.txt
present in the same directory as the files.

1)To execute the program Virus1-CS17BTECH11034.cpp use:

./Virus1-CS17BTECH11034.o

2)To execute the program Virus2-CS17BTECH11034.cpp use:

./Virus2-CS17BTECH11034.o

******************************************************
                     IMPORTANT
THE EXECUTION MAY NOT TERMINATE ON SOME RUNS THIS CAN
HAPPEN WHEN ALL THE CELLS TURN RED AND THE PROGRAM CAN
THEN NEVER TERMINATE, IN THESE SITUATION USE CTRL + C,
TO STOP THE PROGRAM AND THEN RERUN AGAIN
******************************************************
_______________________________________________________________

Output

Each of the programs produce one output files on execution i.e. out-log.txt
