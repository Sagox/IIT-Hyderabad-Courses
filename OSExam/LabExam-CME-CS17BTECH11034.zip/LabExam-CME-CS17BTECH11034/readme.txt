To compile use:

g++ CME-CS17BTECH11034.cpp -lpthread -o CME-CS17BTECH11034

To execute use:
./CME-CS17BTECH11034

There must be inp-params.txt in directory.