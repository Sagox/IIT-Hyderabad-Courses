List of files

This folder consists of the following files:

1)SrcAssgn2-cas-bounded-CS17BTECH11034.cpp
2)SrcAssgn2-cas-bounded-CS17BTECH11034.cpp
3)SrcAssgn2-cas-bounded-CS17BTECH11034.cpp
4)ReportAssgn2-CS17BTECH11034.pdf
_____________________________________________________________

Compiling the files

1)To compile the file SrcAssgn2-tas-CS17BTECH11034.cpp use:

g++ SrcAssgn2-tas-CS17BTECH11034.cpp -lpthread -o SrcAssgn2-tas-CS17BTECH11034

2)To compile the file SrcAssgn2-cas-CS17BTECH11034.cpp use:

g++ SrcAssgn2-cas-CS17BTECH11034.cpp -lpthread -o SrcAssgn2-cas-CS17BTECH11034

3)To compile the file SrcAssgn2-cas-bounded-CS17BTECH11034.cpp use:

g++ SrcAssgn2-cas-bounded-CS17BTECH11034.cpp -lpthread -o SrcAssgn2-cas-bounded-CS17BTECH11034
______________________________________________________________

Executing the program

Before executing there must be a file called inp-params.txt
present in the same directory as the files.

1)To execute the program SrcAssgn2-tas-CS17BTECH11034.cpp use:

./SrcAssgn2-tas-CS17BTECH11034

2)To execute the program SrcAssgn2-tas-CS17BTECH11034.cpp use:

./SrcAssgn2-cas-CS17BTECH11034

3)To execute the program SrcAssgn2-tas-CS17BTECH11034.cpp use:

./SrcAssgn2-cas-bounded-CS17BTECH11034

_______________________________________________________________

Output

The output of any of the programs is a file,
1)bounded-cas/tas/cas-output.txt