List of files

This folder consists of the following files:

1)prod_cons-Locks-CS17BTECH11034.cpp
2)prod_cons-Sem-CS17BTECH11034.cpp
3)ReportAssgn3-CS17BTECH11034.pdf
_____________________________________________________________

Compiling the files

1)To compile the files use:

g++ prod_cons-Sem-CS17BTECH11034.cpp -lpthread -o prod_cons-Sem-CS17BTECH11034
g++ prod_cons-Locks-CS17BTECH11034.cpp -lpthread -o prod_cons-Locks-CS17BTECH11034
______________________________________________________________

Executing the program

Before executing there must be a file called inp-params.txt
present in the same directory as the files.

1)To execute the program SrcAssgn2-tas-CS17BTECH11034.cpp use:

./prod_cons-Sem-CS17BTECH11034

2)To execute the program SrcAssgn2-tas-CS17BTECH11034.cpp use:

./prod_cons-Locks-CS17BTECH11034
_______________________________________________________________

Output

The output of any of the programs is a file,
1)output-semaphore.txt
or
2)output-lock.txt