List of files

This folder consists of the following files:

1)rw-CS17BTECH11034.cpp
2)frw-CS17BTECH11034.cpp
3)Assgn4-report-CS17BTECH11034.pdf
_____________________________________________________________

Compiling the files

1)To compile the file rw-CS17BTECH11034.cpp use:

g++ rw-CS17BTECH11034.cpp -lpthread -o rw-CS17BTECH11034

2)To compile the file frw-CS17BTECH11034.cpp use:

g++ frw-CS17BTECH11034.cpp -lpthread -o frw-CS17BTECH11034
______________________________________________________________

Executing the program

Before executing there must be a file called inp-params.txt
present in the same directory as the files.

1)To execute the program rw-CS17BTECH11034.cpp use:

./rw-CS17BTECH11034

2)To execute the program frw-CS17BTECH11034.cpp use:

./frw-CS17BTECH11034
_______________________________________________________________

Output

Each of the programs produce two output files on execution:
1) A log file i.e. RW/FairRW-log.txt
2) A file containing averages/stats i.e. RW/FairRW-Average.txt