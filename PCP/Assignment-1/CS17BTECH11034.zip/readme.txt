List of files

This folder consists of the following files:

1) Src-CS17BTECH11034.cpp
2) report.pdf
_____________________________________________________________

Compiling the files

1)To compile the file rw-CS17BTECH11034.cpp use:

g++ Src-CS17BTECH11034.cpp -lpthread -o Src-CS17BTECH11034.o
______________________________________________________________

Executing the program

Before executing there must be a file called inp-params.txt
present in the same directory as the files.

1)To execute the program Src-CS17BTECH11034.cpp use:

./Src-CS17BTECH11034.o
_______________________________________________________________

Output

The following files will be generated as output:
1) Primes-DAM.txt
2) Primes-SAM1.txt
3) Primes-SAM2.txt
4) Times.txt
