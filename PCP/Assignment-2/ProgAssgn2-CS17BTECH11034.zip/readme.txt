List of files

This folder consists of the following files:

1) SrcAssgn2-CS17BTECH11034.cpp
2) report.pdf
_____________________________________________________________

Compiling the files

1)To compile the file SrcAssgn2-CS17BTECH11034.cpp use:

g++ SrcAssgn2-CS17BTECH11034.cpp -lpthread -o SrcAssgn2-CS17BTECH11034.o
______________________________________________________________

Executing the program

Before executing there must be a file called inp-params.txt
present in the same directory as the files.

1)To execute the program SrcAssgn2-CS17BTECH11034.cpp use:

./SrcAssgn2-CS17BTECH11034.o
_______________________________________________________________

Output

The stats for the two algorithms will be printed to STDOUT

The following files will be generated as output:
1) output-log.txt
